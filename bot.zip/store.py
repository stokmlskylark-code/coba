"""Penyimpanan toko; uang dalam rupiah bulat, stok direservasi saat memesan."""

import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path


class ShopError(Exception):
    pass


class Store:
    def __init__(self, path, admin_ids, ttl_hours=24):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, isolation_level=None, timeout=10)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.execute("PRAGMA journal_mode = WAL")
        self.ttl = ttl_hours * 3600
        self.admin_ids = set(admin_ids)
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY, name TEXT NOT NULL, username TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'customer'
                    CHECK(role IN ('customer', 'reseller', 'admin')),
                reseller_request INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products (
                sku TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
                price INTEGER NOT NULL CHECK(price > 0),
                reseller_price INTEGER NOT NULL CHECK(reseller_price > 0 AND reseller_price <= price),
                stock INTEGER NOT NULL CHECK(stock >= 0),
                active INTEGER NOT NULL DEFAULT 1,
                seller_id INTEGER REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_key TEXT NOT NULL UNIQUE,
                user_id INTEGER NOT NULL REFERENCES users(id),
                sku TEXT NOT NULL REFERENCES products(sku),
                product_name TEXT NOT NULL, qty INTEGER NOT NULL CHECK(qty > 0),
                unit_price INTEGER NOT NULL, retail_price INTEGER NOT NULL,
                total INTEGER NOT NULL, reseller INTEGER NOT NULL,
                note TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending_payment'
                    CHECK(status IN ('pending_payment', 'awaiting_confirmation', 'paid',
                        'shipped', 'completed', 'cancelled', 'expired')),
                proof_file_id TEXT, proof_kind TEXT, tracking TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS orders_user ON orders(user_id, id DESC);
            CREATE INDEX IF NOT EXISTS orders_status ON orders(status, expires_at);
            CREATE TABLE IF NOT EXISTS audit (
                id INTEGER PRIMARY KEY, actor_id INTEGER NOT NULL,
                action TEXT NOT NULL, detail TEXT NOT NULL, created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS payments (
                order_id INTEGER PRIMARY KEY REFERENCES orders(id),
                reference TEXT NOT NULL UNIQUE, project TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'pending'
                    CHECK(state IN ('pending', 'completed', 'closed', 'late_completed')),
                provider_status TEXT NOT NULL DEFAULT 'not_checked',
                checked_at INTEGER NOT NULL DEFAULT 0,
                check_after INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS payments_due ON payments(state, check_after);
        """)
        # Migration: tambah seller_id jika belum ada (database lama)
        try:
            self.db.execute("ALTER TABLE products ADD COLUMN seller_id INTEGER REFERENCES users(id)")
        except Exception:
            pass

    def close(self):
        self.db.close()

    @contextmanager
    def transaction(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def _audit(self, actor, action, detail):
        self.db.execute("INSERT INTO audit(actor_id, action, detail, created_at) VALUES (?, ?, ?, ?)",
                        (actor, action, detail, int(time.time())))

    def register(self, user_id, name, username=""):
        self.db.execute("""INSERT INTO users(id, name, username, role, created_at)
            VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET
            name=excluded.name, username=excluded.username""",
                        (user_id, name[:150], username[:100],
                         "admin" if user_id in self.admin_ids else "customer", int(time.time())))
        # Konfigurasi adalah satu-satunya sumber hak admin.
        if user_id in self.admin_ids:
            self.db.execute("UPDATE users SET role='admin' WHERE id=?", (user_id,))
        else:
            self.db.execute("UPDATE users SET role='customer' WHERE id=? AND role='admin'", (user_id,))
        return self.user(user_id)

    def user(self, user_id):
        row = self.db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not row:
            raise ShopError("Pengguna belum menjalankan /start.")
        return row

    def user_stats(self, user_id):
        row = self.db.execute("""
            SELECT count(*) AS completed_orders,
                   coalesce(sum(total), 0) AS total_spending
            FROM orders WHERE user_id=? AND status IN ('paid', 'shipped', 'completed')
        """, (user_id,)).fetchone()
        return dict(row)

    def require_admin(self, user_id):
        if user_id not in self.admin_ids:
            raise ShopError("Perintah ini hanya untuk admin.")

    def request_reseller(self, user_id):
        with self.transaction():
            user = self.user(user_id)
            if user["role"] != "customer":
                raise ShopError("Akun Anda sudah memiliki akses reseller/admin.")
            if user["reseller_request"]:
                raise ShopError("Pengajuan sebelumnya masih menunggu admin.")
            self.db.execute("UPDATE users SET reseller_request=1 WHERE id=?", (user_id,))
            self._audit(user_id, "request_reseller", str(user_id))

    def set_reseller(self, actor, user_id, enabled):
        self.require_admin(actor)
        with self.transaction():
            self.user(user_id)
            if user_id in self.admin_ids:
                raise ShopError("Hak admin diatur melalui ADMIN_IDS, bukan perintah reseller.")
            self.db.execute("UPDATE users SET role=?, reseller_request=0 WHERE id=?",
                            ("reseller" if enabled else "customer", user_id))
            self._audit(actor, "set_reseller", f"{user_id}: {enabled}")

    def reseller_requests(self, actor):
        self.require_admin(actor)
        return self.db.execute("SELECT * FROM users WHERE reseller_request=1 ORDER BY id LIMIT 30").fetchall()

    def save_product(self, actor, sku, name, price, reseller_price, stock, description):
        self.require_admin(actor)
        sku = sku.upper()
        if not (1 <= len(sku) <= 30 and sku.isascii() and
                all(c.isalnum() or c in "_-" for c in sku)):
            raise ShopError("SKU harus 1–30 karakter: huruf, angka, garis bawah atau tanda minus.")
        if not name.strip() or len(name) > 120 or len(description) > 1000:
            raise ShopError("Nama wajib diisi (maks. 120 karakter), deskripsi maks. 1000 karakter.")
        if not all(type(value) is int for value in (price, reseller_price, stock)):
            raise ShopError("Harga dan stok harus bilangan bulat.")
        if not (0 < reseller_price <= price <= 1_000_000_000 and 0 <= stock <= 1_000_000):
            raise ShopError("Harga harus 1–1.000.000.000, harga reseller ≤ harga normal, stok 0–1.000.000.")
        with self.transaction():
            self.db.execute("""INSERT INTO products
                (sku, name, price, reseller_price, stock, description) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price=excluded.price,
                reseller_price=excluded.reseller_price, stock=excluded.stock,
                description=excluded.description""", (sku, name, price, reseller_price, stock, description))
            self._audit(actor, "save_product", sku)

    def set_stock(self, actor, sku, stock):
        self.require_admin(actor)
        if type(stock) is not int or not 0 <= stock <= 1_000_000:
            raise ShopError("Stok harus 0–1.000.000.")
        with self.transaction():
            self.product(sku)
            self.db.execute("UPDATE products SET stock=? WHERE sku=?", (stock, sku.upper()))
            self._audit(actor, "set_stock", f"{sku.upper()}: {stock}")

    def set_active(self, actor, sku, active):
        self.require_admin(actor)
        with self.transaction():
            self.product(sku)
            self.db.execute("UPDATE products SET active=? WHERE sku=?", (int(active), sku.upper()))
            self._audit(actor, "set_active", f"{sku.upper()}: {active}")

    def product(self, sku):
        row = self.db.execute("SELECT * FROM products WHERE sku=?", (sku.upper(),)).fetchone()
        if not row:
            raise ShopError("Produk tidak ditemukan.")
        return row

    def catalog(self, page=0, query="", include_hidden=False):
        return self.db.execute("""SELECT * FROM products WHERE (active=1 OR ?)
            AND (instr(lower(name), lower(?)) > 0 OR instr(lower(sku), lower(?)) > 0)
            ORDER BY sku LIMIT 8 OFFSET ?""", (include_hidden, query, query, max(0, page) * 8)).fetchall()

    def my_products(self, seller_id, page=0, query=""):
        return self.db.execute("""SELECT * FROM products WHERE seller_id=?
            AND (instr(lower(name), lower(?)) > 0 OR instr(lower(sku), lower(?)) > 0)
            ORDER BY sku LIMIT 8 OFFSET ?""", (seller_id, query, query, max(0, page) * 8)).fetchall()

    def save_reseller_product(self, actor, sku, name, price, stock, description):
        user = self.user(actor)
        if user["role"] != "reseller":
            raise ShopError("Hanya reseller yang dapat menambahkan produk.")
        sku = sku.upper()
        if not (1 <= len(sku) <= 30 and sku.isascii() and
                all(c.isalnum() or c in "_-" for c in sku)):
            raise ShopError("SKU harus 1–30 karakter: huruf, angka, garis bawah atau tanda minus.")
        if not name.strip() or len(name) > 120 or len(description) > 1000:
            raise ShopError("Nama wajib diisi (maks. 120 karakter), deskripsi maks. 1000 karakter.")
        if not all(type(value) is int for value in (price, stock)):
            raise ShopError("Harga dan stok harus bilangan bulat.")
        if not (0 < price <= 1_000_000_000 and 0 <= stock <= 1_000_000):
            raise ShopError("Harga harus 1–1.000.000.000, stok 0–1.000.000.")
        with self.transaction():
            existing = self.db.execute("SELECT seller_id FROM products WHERE sku=?", (sku,)).fetchone()
            if existing and existing["seller_id"] != actor:
                raise ShopError("SKU sudah dimiliki seller lain.")
            self.db.execute("""INSERT INTO products
                (sku, name, price, reseller_price, stock, description, seller_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price=excluded.price,
                reseller_price=excluded.price, stock=excluded.stock,
                description=excluded.description, seller_id=excluded.seller_id""",
                (sku, name, price, price, stock, description, actor))
            self._audit(actor, "save_reseller_product", sku)

    def delete_product(self, actor, sku):
        user = self.user(actor)
        if user["role"] != "reseller":
            raise ShopError("Hanya reseller yang dapat menghapus produk.")
        with self.transaction():
            product = self.db.execute("SELECT * FROM products WHERE sku=? AND seller_id=?",
                                      (sku.upper(), actor)).fetchone()
            if not product:
                raise ShopError("Produk tidak ditemukan atau bukan milik Anda.")
            pending = self.db.execute("""SELECT count(*) FROM orders WHERE sku=?
                AND status IN ('pending_payment', 'awaiting_confirmation')""", (sku.upper(),)).fetchone()[0]
            if pending:
                raise ShopError("Tidak dapat menghapus produk yang sedang dalam pesanan aktif.")
            self.db.execute("DELETE FROM products WHERE sku=? AND seller_id=?", (sku.upper(), actor))
            self._audit(actor, "delete_product", sku.upper())

    def _expire(self, now):
        rows = self.db.execute("""SELECT id, sku, qty FROM orders WHERE status='pending_payment' AND expires_at<=?
            AND NOT EXISTS (SELECT 1 FROM payments WHERE payments.order_id=orders.id)""",
                               (now,)).fetchall()
        for row in rows:
            self.db.execute("UPDATE products SET stock=stock+? WHERE sku=?", (row["qty"], row["sku"]))
            self.db.execute("UPDATE orders SET status='expired', updated_at=? WHERE id=?", (now, row["id"]))
            self._audit(0, "expire_order", str(row["id"]))

    def expire(self):
        with self.transaction():
            self._expire(int(time.time()))

    def create_order(self, user_id, sku, qty, note, request_key, payment_project=None):
        if type(qty) is not int or not 1 <= qty <= 1000:
            raise ShopError("Jumlah pembelian harus 1–1000.")
        if not note.strip() or len(note) > 1000:
            raise ShopError("Isi catatan pembelian, maks. 1000 karakter.")
        now = int(time.time())
        with self.transaction():
            self._expire(now)
            existing = self.db.execute("SELECT * FROM orders WHERE request_key=?", (request_key,)).fetchone()
            if existing:
                if existing["user_id"] != user_id:
                    raise ShopError("Identitas permintaan tidak cocok.")
                return existing
            user = self.user(user_id)
            product = self.product(sku)
            if not product["active"]:
                raise ShopError("Produk sedang dinonaktifkan.")
            pending = self.db.execute("""SELECT count(*) FROM orders WHERE user_id=?
                AND status IN ('pending_payment', 'awaiting_confirmation')""", (user_id,)).fetchone()[0]
            if pending >= 5:
                raise ShopError("Maksimal 5 pesanan belum dibayar/dikonfirmasi. Selesaikan atau batalkan dahulu.")
            changed = self.db.execute("UPDATE products SET stock=stock-? WHERE sku=? AND stock>=?",
                                      (qty, product["sku"], qty))
            if not changed.rowcount:
                raise ShopError("Stok tidak cukup.")
            reseller = user["role"] == "reseller"
            price = product["reseller_price"] if reseller else product["price"]
            cursor = self.db.execute("""INSERT INTO orders(request_key, user_id, sku, product_name,
                qty, unit_price, retail_price, total, reseller, note, created_at, expires_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                                    (request_key, user_id, product["sku"], product["name"], qty,
                                     price, product["price"], price * qty, reseller, note, now, now + self.ttl, now))
            self._audit(user_id, "create_order", str(cursor.lastrowid))
            if payment_project:
                self.db.execute("INSERT INTO payments(order_id, reference, project) VALUES (?, ?, ?)",
                                (cursor.lastrowid, "TG-" + uuid.uuid4().hex, payment_project))
            return self.order(cursor.lastrowid, user_id)

    def order(self, order_id, actor):
        row = self.db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not row or (row["user_id"] != actor and actor not in self.admin_ids):
            raise ShopError("Pesanan tidak ditemukan atau bukan milik Anda.")
        return row

    def orders(self, actor, page=0, admin=False, status=None):
        if admin:
            self.require_admin(actor)
        return self.db.execute("""SELECT * FROM orders WHERE (user_id=? OR ?)
            AND (? IS NULL OR status=?) ORDER BY id DESC LIMIT 8 OFFSET ?""",
                               (actor, admin, status, status, max(0, page) * 8)).fetchall()

    def submit_proof(self, actor, order_id, file_id, kind):
        if kind not in ("photo", "document") or not file_id:
            raise ShopError("Bukti harus berupa foto atau dokumen.")
        self.expire()
        with self.transaction():
            row = self.order(order_id, actor)
            if self.payment(order_id, actor):
                raise ShopError("Pesanan Pakasir diverifikasi otomatis. Gunakan /cekbayar ID, bukan bukti transfer.")
            if row["user_id"] != actor:
                raise ShopError("Hanya pemilik pesanan yang dapat mengirim bukti.")
            if row["status"] not in ("pending_payment", "awaiting_confirmation"):
                raise ShopError("Pesanan ini tidak menerima bukti pembayaran lagi.")
            self.db.execute("""UPDATE orders SET status='awaiting_confirmation', proof_file_id=?,
                proof_kind=?, updated_at=? WHERE id=?""", (file_id, kind, int(time.time()), order_id))
            self._audit(actor, "submit_proof", str(order_id))

    def cancel(self, actor, order_id):
        with self.transaction():
            row = self.order(order_id, actor)
            if self.payment(order_id, actor):
                raise ShopError("Pembatalan Pakasir harus diperiksa melalui gateway terlebih dahulu.")
            # Bukti yang sudah masuk wajib ditinjau admin agar pembayaran tidak terabaikan.
            if row["status"] != "pending_payment":
                raise ShopError("Hanya pesanan menunggu pembayaran yang dapat dibatalkan. Hubungi admin untuk status lain.")
            self.db.execute("UPDATE orders SET status='cancelled', updated_at=? WHERE id=?",
                            (int(time.time()), order_id))
            self.db.execute("UPDATE products SET stock=stock+? WHERE sku=?", (row["qty"], row["sku"]))
            self._audit(actor, "cancel_order", str(order_id))

    def transition(self, actor, order_id, action, detail=""):
        self.require_admin(actor)
        transitions = {"approve": ("awaiting_confirmation", "paid"),
                       "reject": ("awaiting_confirmation", "pending_payment"),
                       "complete": ("paid", "completed")}
        if action not in transitions:
            raise ShopError("Aksi pesanan tidak dikenal.")
        if action == "reject" and (not detail.strip() or len(detail) > 500):
            raise ShopError("Isi alasan penolakan (maks. 500 karakter).")
        with self.transaction():
            row = self.order(order_id, actor)
            if action in ("approve", "reject") and self.payment(order_id, actor):
                raise ShopError("Pembayaran Pakasir hanya boleh dikonfirmasi oleh API Pakasir.")
            before, after = transitions[action]
            if row["status"] != before:
                raise ShopError(f"Status tidak cocok untuk aksi ini: {row['status']}.")
            now = int(time.time())
            self.db.execute("""UPDATE orders SET status=?, updated_at=?, expires_at=?,
                proof_file_id=?, proof_kind=? WHERE id=?""",
                            (after, now,
                             now + self.ttl if action == "reject" else row["expires_at"],
                             None if action == "reject" else row["proof_file_id"],
                             None if action == "reject" else row["proof_kind"], order_id))
            self._audit(actor, action, f"{order_id}: {detail}")
            return self.order(order_id, actor)

    def stats(self, actor, admin=False):
        if admin:
            self.require_admin(actor)
        rows = self.db.execute("""SELECT status, count(*) AS count, coalesce(sum(total), 0) AS total,
            coalesce(sum(CASE WHEN reseller=1 THEN (retail_price-unit_price)*qty ELSE 0 END), 0) AS saving
            FROM orders WHERE (user_id=? OR ?) GROUP BY status""", (actor, admin)).fetchall()
        return {row["status"]: dict(row) for row in rows}

    def payment(self, order_id, actor):
        self.order(order_id, actor)
        return self.db.execute("SELECT * FROM payments WHERE order_id=?", (order_id,)).fetchone()

    def due_payments(self, now, limit=3):
        return self.db.execute("""SELECT p.*, o.user_id, o.total, o.expires_at FROM payments p
            JOIN orders o ON o.id=p.order_id WHERE p.state IN ('pending', 'closed') AND p.check_after<=?
            ORDER BY p.check_after, p.order_id LIMIT ?""", (now, limit)).fetchall()

    def schedule_payment_check(self, order_id, after):
        self.db.execute("UPDATE payments SET check_after=? WHERE order_id=?", (after, order_id))

    def apply_payment_status(self, order_id, reference, project, amount, provider_status, close_as=None):
        if close_as not in (None, "cancelled", "expired"):
            raise ShopError("Status penutupan pembayaran tidak valid.")
        if close_as and provider_status not in ("not_found", "canceled", "cancelled", "expired"):
            raise ShopError("Gateway belum memastikan transaksi aman untuk ditutup.")
        now = int(time.time())
        with self.transaction():
            payment = self.db.execute("SELECT * FROM payments WHERE order_id=?", (order_id,)).fetchone()
            order = self.db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            if (not payment or not order or payment["reference"] != reference or payment["project"] != project
                    or type(amount) is not int or order["total"] != amount):
                raise ShopError("Identitas/nominal pembayaran tidak cocok dengan invoice.")
            if payment["state"] in ("completed", "late_completed"):
                return None
            event = None
            state = payment["state"]
            if provider_status == "completed":
                if order["status"] == "pending_payment":
                    self.db.execute("UPDATE orders SET status='paid', updated_at=? WHERE id=?", (now, order_id))
                    state, event = "completed", "paid"
                else:
                    # Pembayaran sesudah stok dilepas harus direkonsiliasi, bukan mengirim barang yang mungkin habis.
                    state, event = "late_completed", "late_completed"
            elif close_as and order["status"] == "pending_payment":
                self.db.execute("UPDATE orders SET status=?, updated_at=? WHERE id=?", (close_as, now, order_id))
                self.db.execute("UPDATE products SET stock=stock+? WHERE sku=?", (order["qty"], order["sku"]))
                state, event = "closed", close_as
            self.db.execute("""UPDATE payments SET state=?, provider_status=?, checked_at=?, check_after=?
                WHERE order_id=?""", (state, provider_status, now, now + (3600 if state == "closed" else 60), order_id))
            if event:
                self._audit(0, "pakasir_" + event, str(order_id))
            return event

    def payment_issues(self, actor):
        self.require_admin(actor)
        return self.db.execute("""SELECT o.id, o.user_id, o.total, p.reference FROM payments p
            JOIN orders o ON o.id=p.order_id WHERE p.state='late_completed' ORDER BY o.id DESC LIMIT 30""").fetchall()

    def admin_counts(self, actor):
        self.require_admin(actor)
        return {
            "users": self.db.execute("SELECT count(*) FROM users").fetchone()[0],
            "resellers": self.db.execute("SELECT count(*) FROM users WHERE role='reseller'").fetchone()[0],
            "products": self.db.execute("SELECT count(*) FROM products WHERE active=1").fetchone()[0],
            "low_stock": self.db.execute("SELECT count(*) FROM products WHERE active=1 AND stock<=5").fetchone()[0],
        }

    def audit(self, actor):
        self.require_admin(actor)
        return self.db.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 15").fetchall()

    def get_offset(self):
        row = self.db.execute("SELECT value FROM settings WHERE key='telegram_offset'").fetchone()
        return int(row[0]) if row else 0

    def set_offset(self, offset):
        self.db.execute("INSERT INTO settings(key, value) VALUES ('telegram_offset', ?) "
                        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(offset),))
