"""Web server untuk Telegram Mini Apps — pendaftaran reseller."""

import json
import logging
import os
import sqlite3
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

LOG = logging.getLogger("webapp")
DB_PATH = os.getenv("DATABASE_PATH", "data/shop.sqlite3")
ADMIN_IDS = set()
HOST = os.getenv("WEB_HOST", "0.0.0.0")
PORT = int(os.getenv("WEB_PORT", "8080"))

TEMPLATE_DIR = Path(__file__).parent / "templates"


def get_db():
    db = sqlite3.connect(DB_PATH, timeout=5)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db


def register_reseller(user_id, shop_name, description):
    db = get_db()
    try:
        user = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        if not user:
            return False, "User belum terdaftar di bot."
        if user["role"] == "reseller":
            return False, "Anda sudah menjadi reseller."
        if user["reseller_request"]:
            return False, "Pengajuan sebelumnya masih menunggu admin."
        now = int(time.time())
        db.execute("UPDATE users SET reseller_request=1 WHERE id=?", (user_id,))
        db.execute("INSERT INTO audit(actor_id, action, detail, created_at) VALUES (?, ?, ?, ?)",
                   (user_id, "request_reseller_web", f"{shop_name}: {description}", now))
        db.commit()
        return True, "Berhasil"
    except Exception as exc:
        LOG.error("Register error: %s", exc)
        return False, "Terjadi kesalahan."
    finally:
        db.close()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        LOG.info(format, *args)

    def _send(self, code, content_type, body):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._serve_template("reseller.html", "text/html")
        else:
            self._send(404, "text/plain", "Not Found")

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/register":
            self._handle_register()
        else:
            self._send(404, "text/plain", "Not Found")

    def _serve_template(self, filename, content_type):
        path = TEMPLATE_DIR / filename
        if not path.exists():
            self._send(404, "text/plain", "Template not found")
            return
        body = path.read_bytes()
        self._send(200, content_type, body)

    def _handle_register(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            self._send(400, "application/json", json.dumps({"success": False, "message": "Invalid JSON"}))
            return

        user_id = data.get("user_id")
        shop_name = (data.get("shop_name") or "").strip()
        description = (data.get("description") or "").strip()

        if not user_id or not isinstance(user_id, int):
            self._send(400, "application/json", json.dumps({"success": False, "message": "user_id invalid"}))
            return
        if not shop_name or len(shop_name) > 50:
            self._send(400, "application/json", json.dumps({"success": False, "message": "Nama toko tidak valid"}))
            return
        if not description or len(description) > 200:
            self._send(400, "application/json", json.dumps({"success": False, "message": "Deskripsi tidak valid"}))
            return

        ok, msg = register_reseller(user_id, shop_name, description)
        self._send(200, "application/json", json.dumps({"success": ok, "message": msg}))


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        db = get_db()
        for row in db.execute("SELECT id FROM users WHERE role='admin'").fetchall():
            ADMIN_IDS.add(row["id"])
        db.close()
    except Exception:
        pass

    server = HTTPServer((HOST, PORT), Handler)
    LOG.info("Web app berjalan di http://%s:%s", HOST, PORT)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        LOG.info("Web app dihentikan.")
    server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
